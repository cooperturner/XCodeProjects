import SwiftUI
import SwiftData

@main
struct FitTrackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [
            User.self,
            FoodLog.self,
            WeightEntry.self,
            MealPlanRecord.self,
            ExercisePlanRecord.self
        ])
    }
}
