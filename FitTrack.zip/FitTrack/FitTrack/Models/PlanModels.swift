import Foundation

struct MealItem: Codable, Identifiable {
    var id = UUID()
    let type: String
    let name: String
    let calories: Int
    let protein: Int
    let carbs: Int
    let fat: Int
    let ingredients: [String]
    let prep: String

    enum CodingKeys: String, CodingKey {
        case type, name, calories, protein, carbs, fat, ingredients, prep
    }
}

struct DayMealPlan: Codable, Identifiable {
    var id = UUID()
    let day: String
    let meals: [MealItem]

    var totalCalories: Int { meals.reduce(0) { $0 + $1.calories } }

    enum CodingKeys: String, CodingKey { case day, meals }
}

struct WeeklyMealPlan: Codable {
    let days: [DayMealPlan]
}

struct ExerciseItem: Codable, Identifiable {
    var id = UUID()
    let name: String
    let sets: Int
    let reps: String
    let rest: String
    let notes: String

    enum CodingKeys: String, CodingKey {
        case name, sets, reps, rest, notes
    }
}

struct DayExercisePlan: Codable, Identifiable {
    var id = UUID()
    let day: String
    let workoutType: String
    let duration: String
    let isRest: Bool
    let exercises: [ExerciseItem]
    let warmup: String
    let cooldown: String

    enum CodingKeys: String, CodingKey {
        case day, workoutType, duration, isRest, exercises, warmup, cooldown
    }
}

struct WeeklyExercisePlan: Codable {
    let days: [DayExercisePlan]
}

struct MacroTargets {
    let proteinG: Int
    let carbsG: Int
    let fatG: Int

    static func calculate(weightKg: Float, calories: Int, goal: String) -> MacroTargets {
        let proteinPerKg: Float = goal == "gain_muscle" ? 2.2 : goal == "lose_weight" ? 2.0 : 1.7
        let fatPct: Float = goal == "gain_muscle" ? 0.25 : 0.30
        let proteinG = Int(weightKg * proteinPerKg)
        let fatG = Int(Float(calories) * fatPct / 9)
        let carbsG = max(0, (calories - proteinG * 4 - fatG * 9) / 4)
        return MacroTargets(proteinG: proteinG, carbsG: carbsG, fatG: fatG)
    }
}
