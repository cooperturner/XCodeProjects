import SwiftData
import Foundation

class PlanRepository {
    private let modelContext: ModelContext

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }

    // MARK: - Meal Plan

    func getLatestMealPlan(userId: String) throws -> WeeklyMealPlan? {
        let descriptor = FetchDescriptor<MealPlanRecord>(
            predicate: #Predicate { $0.userId == userId },
            sortBy: [SortDescriptor(\.weekStartDate, order: .reverse)]
        )
        guard let record = try modelContext.fetch(descriptor).first else { return nil }
        return decodeMealPlan(record.planText)
    }

    func generateMealPlan(user: User, weekStart: String) async throws -> WeeklyMealPlan {
        guard !user.claudeApiKey.isEmpty else {
            throw PlanError.noApiKey
        }
        let goalLabel = goalText(user.goal)
        let macros = MacroTargets.calculate(weightKg: user.weightKg, calories: user.dailyCalorieTarget, goal: user.goal)
        let prefsLine = buildPrefsLine(user)

        let breakfastKcal = Int(Double(user.dailyCalorieTarget) * 0.25)
        let lunchKcal     = Int(Double(user.dailyCalorieTarget) * 0.35)
        let dinnerKcal    = Int(Double(user.dailyCalorieTarget) * 0.30)
        let snackKcal     = user.dailyCalorieTarget - breakfastKcal - lunchKcal - dinnerKcal

        let prompt = """
            You are a nutrition expert. Generate a 7-day meal plan for this person:
            Goal: \(goalLabel) | Age: \(user.age) | Weight: \(user.weightKg)kg | Height: \(user.heightCm)cm | Gender: \(user.gender)
            Daily calorie target: \(user.dailyCalorieTarget) kcal | Protein: \(macros.proteinG)g | Carbs: \(macros.carbsG)g | Fat: \(macros.fatG)g
            \(prefsLine)

            CRITICAL CALORIE RULES — you MUST follow these exactly:
            1. Each day MUST contain exactly 4 meals: Breakfast, Lunch, Dinner, Snack.
            2. Target calories per meal: Breakfast ~\(breakfastKcal) kcal, Lunch ~\(lunchKcal) kcal, Dinner ~\(dinnerKcal) kcal, Snack ~\(snackKcal) kcal.
            3. The 4 meal calories MUST sum to EXACTLY \(user.dailyCalorieTarget) kcal (±20 kcal). Use larger portions if needed.
            4. Before outputting, verify: Breakfast + Lunch + Dinner + Snack = \(user.dailyCalorieTarget). If not, adjust portions until they do.
            5. Do NOT round down — use realistic portions that genuinely hit the calorie targets.

            Respond with ONLY a valid JSON object — no markdown, no explanation, no trailing text.
            {"days":[{"day":"Monday","meals":[{"type":"Breakfast","name":"Oats with Banana","calories":\(breakfastKcal),"protein":15,"carbs":60,"fat":8,"ingredients":["100g oats","250ml milk","1 banana"],"prep":"Cook oats, top with banana."},{"type":"Lunch",...},{"type":"Dinner",...},{"type":"Snack",...}]},{"day":"Tuesday",...},{"day":"Wednesday",...},{"day":"Thursday",...},{"day":"Friday",...},{"day":"Saturday",...},{"day":"Sunday",...}]}

            Rules: all 7 days required; ingredients 3-5 items; prep under 15 words.
            """

        let text = try await ClaudeService.shared.send(apiKey: user.claudeApiKey, prompt: prompt)
        guard let plan = decodeMealPlan(ClaudeService.shared.extractJson(text)) else {
            throw PlanError.parseFailed("Could not parse meal plan — try regenerating.")
        }
        try saveMealPlan(userId: user.id, weekStart: weekStart, plan: plan)
        return plan
    }

    func swapMeal(apiKey: String, day: String, meal: MealItem) async throws -> MealItem {
        let prompt = """
            Suggest an alternative \(meal.type) meal to replace "\(meal.name)".
            Match these targets: \(meal.calories) kcal | Protein: \(meal.protein)g | Carbs: \(meal.carbs)g | Fat: \(meal.fat)g

            Respond with ONLY a JSON object:
            {"type":"\(meal.type)","name":"Alternative name","calories":\(meal.calories),"protein":\(meal.protein),"carbs":\(meal.carbs),"fat":\(meal.fat),"ingredients":["item1","item2"],"prep":"Brief prep."}
            """
        let text = try await ClaudeService.shared.send(apiKey: apiKey, prompt: prompt, maxTokens: 512)
        let json = ClaudeService.shared.extractJson(text)
        guard let data = json.data(using: .utf8),
              let item = try? JSONDecoder().decode(MealItem.self, from: data) else {
            throw PlanError.parseFailed("Could not parse swap response.")
        }
        return item
    }

    func saveMealPlan(userId: String, weekStart: String, plan: WeeklyMealPlan) throws {
        let descriptor = FetchDescriptor<MealPlanRecord>(
            predicate: #Predicate { $0.userId == userId }
        )
        let existing = try modelContext.fetch(descriptor)
        existing.forEach { modelContext.delete($0) }
        let json = (try? JSONEncoder().encode(plan)).flatMap { String(data: $0, encoding: .utf8) } ?? ""
        modelContext.insert(MealPlanRecord(userId: userId, weekStartDate: weekStart, planText: json))
        try modelContext.save()
    }

    // MARK: - Exercise Plan

    func getLatestExercisePlan(userId: String) throws -> WeeklyExercisePlan? {
        let descriptor = FetchDescriptor<ExercisePlanRecord>(
            predicate: #Predicate { $0.userId == userId },
            sortBy: [SortDescriptor(\.weekStartDate, order: .reverse)]
        )
        guard let record = try modelContext.fetch(descriptor).first else { return nil }
        return decodeExercisePlan(record.planText)
    }

    func generateExercisePlan(user: User, weekStart: String) async throws -> WeeklyExercisePlan {
        guard !user.claudeApiKey.isEmpty else { throw PlanError.noApiKey }
        let goalLabel = goalTextExercise(user.goal)
        let sportLine = user.sport.isEmpty ? "" :
            "Sport: \(user.sport) — design sessions to directly improve performance in this sport (sport-specific conditioning, strength, and movement patterns)."

        let prompt = """
            You are a fitness expert. Generate a 7-day exercise plan for this person:
            Goal: \(goalLabel) | Age: \(user.age) | Weight: \(user.weightKg)kg | Gender: \(user.gender)
            \(sportLine)

            Respond with ONLY a valid JSON object — no markdown, no explanation, no trailing text.
            {"days":[{"day":"Monday","workoutType":"Strength Training","duration":"45 min","isRest":false,"exercises":[{"name":"Squat","sets":3,"reps":"10-12","rest":"60 sec","notes":"Keep chest up."}],"warmup":"5 min walk","cooldown":"5 min stretch"},{"day":"Tuesday",...},{"day":"Wednesday",...},{"day":"Thursday",...},{"day":"Friday",...},{"day":"Saturday",...},{"day":"Sunday",...}]}

            Rest day format: {"day":"...","workoutType":"Rest","duration":"","isRest":true,"exercises":[],"warmup":"","cooldown":""}
            Rules: all 7 days required; 1-2 rest days; 4-6 exercises per workout day; notes under 8 words.
            """

        let text = try await ClaudeService.shared.send(apiKey: user.claudeApiKey, prompt: prompt)
        guard let plan = decodeExercisePlan(ClaudeService.shared.extractJson(text)) else {
            throw PlanError.parseFailed("Could not parse exercise plan — try regenerating.")
        }
        try saveExercisePlan(userId: user.id, weekStart: weekStart, plan: plan)
        return plan
    }

    func swapExercise(apiKey: String, exercise: ExerciseItem, workoutType: String) async throws -> ExerciseItem {
        let prompt = """
            Suggest an alternative exercise to replace "\(exercise.name)" in a \(workoutType) workout.
            Respond with ONLY a JSON object:
            {"name":"Alternative exercise","sets":3,"reps":"10-12","rest":"60 sec","notes":"Form tip"}
            """
        let text = try await ClaudeService.shared.send(apiKey: apiKey, prompt: prompt, maxTokens: 256)
        let json = ClaudeService.shared.extractJson(text)
        guard let data = json.data(using: .utf8),
              let item = try? JSONDecoder().decode(ExerciseItem.self, from: data) else {
            throw PlanError.parseFailed("Could not parse swap response.")
        }
        return item
    }

    func saveExercisePlan(userId: String, weekStart: String, plan: WeeklyExercisePlan) throws {
        let descriptor = FetchDescriptor<ExercisePlanRecord>(
            predicate: #Predicate { $0.userId == userId }
        )
        let existing = try modelContext.fetch(descriptor)
        existing.forEach { modelContext.delete($0) }
        let json = (try? JSONEncoder().encode(plan)).flatMap { String(data: $0, encoding: .utf8) } ?? ""
        modelContext.insert(ExercisePlanRecord(userId: userId, weekStartDate: weekStart, planText: json))
        try modelContext.save()
    }

    // MARK: - Helpers

    private func decodeMealPlan(_ json: String) -> WeeklyMealPlan? {
        guard let data = json.data(using: .utf8) else { return nil }
        return try? JSONDecoder().decode(WeeklyMealPlan.self, from: data)
    }

    private func decodeExercisePlan(_ json: String) -> WeeklyExercisePlan? {
        guard let data = json.data(using: .utf8) else { return nil }
        return try? JSONDecoder().decode(WeeklyExercisePlan.self, from: data)
    }

    private func goalText(_ goal: String) -> String {
        switch goal {
        case "gain_muscle": return "gain muscle mass"
        case "lose_weight": return "lose weight and burn fat"
        default: return "maintain current weight"
        }
    }

    private func goalTextExercise(_ goal: String) -> String {
        switch goal {
        case "gain_muscle": return "gain muscle mass and strength"
        case "lose_weight": return "lose weight and improve cardio fitness"
        default: return "maintain fitness and overall health"
        }
    }

    private func buildPrefsLine(_ user: User) -> String {
        var parts: [String] = []
        if !user.dietaryPreferences.isEmpty { parts.append("Dietary preferences: \(user.dietaryPreferences).") }
        if !user.dislikedFoods.isEmpty { parts.append("NEVER include these foods: \(user.dislikedFoods).") }
        return parts.joined(separator: " ")
    }
}

enum PlanError: Error, LocalizedError {
    case noApiKey
    case parseFailed(String)

    var errorDescription: String? {
        switch self {
        case .noApiKey: return "Claude API key not set. Go to Settings to add it."
        case .parseFailed(let msg): return msg
        }
    }
}
