import SwiftData
import Foundation

@Observable
class AuthViewModel {
    var isLoading = false
    var error = ""

    private let repo: UserRepository
    private let session = SessionManager.shared

    init(modelContext: ModelContext) {
        self.repo = UserRepository(modelContext: modelContext)
    }

    func login(username: String, password: String) async -> Bool {
        guard !username.isEmpty, !password.isEmpty else {
            error = "Please fill in all fields"; return false
        }
        isLoading = true
        error = ""
        defer { isLoading = false }
        do {
            guard let user = try repo.findUser(username: username.lowercased()) else {
                error = "Invalid username or password"; return false
            }
            guard user.passwordHash == User.hash(password) else {
                error = "Invalid username or password"; return false
            }
            session.login(userId: user.id, profileComplete: user.profileComplete)
            KeychainHelper.save(username.lowercased(), key: "saved_username")
            KeychainHelper.save(password, key: "saved_password")
            return true
        } catch {
            self.error = error.localizedDescription; return false
        }
    }

    func register(username: String, password: String, confirm: String) async -> Bool {
        guard !username.isEmpty, !password.isEmpty else {
            error = "Please fill in all fields"; return false
        }
        guard password == confirm else {
            error = "Passwords do not match"; return false
        }
        guard password.count >= 6 else {
            error = "Password must be at least 6 characters"; return false
        }
        isLoading = true
        error = ""
        defer { isLoading = false }
        do {
            let user = try repo.createUser(username: username, password: password)
            session.login(userId: user.id, profileComplete: false)
            KeychainHelper.save(username.lowercased(), key: "saved_username")
            KeychainHelper.save(password, key: "saved_password")
            return true
        } catch {
            self.error = error.localizedDescription; return false
        }
    }

    func clearError() { error = "" }
}
