import SwiftData
import Foundation

@Observable
class PlanViewModel {
    var mealPlan: WeeklyMealPlan?
    var exercisePlan: WeeklyExercisePlan?
    var isGeneratingMeal = false
    var isGeneratingExercise = false
    var swappingKey: String?
    var error = ""

    private let planRepo: PlanRepository
    private let userRepo: UserRepository
    private let session = SessionManager.shared

    private var weekStart: String {
        let cal = Calendar.current
        var comps = cal.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date())
        comps.weekday = 2
        let monday = cal.date(from: comps) ?? Date()
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        return f.string(from: monday)
    }

    init(modelContext: ModelContext) {
        self.planRepo = PlanRepository(modelContext: modelContext)
        self.userRepo = UserRepository(modelContext: modelContext)
        loadSaved()
    }

    private func loadSaved() {
        guard let userId = session.userId else { return }
        mealPlan = try? planRepo.getLatestMealPlan(userId: userId)
        exercisePlan = try? planRepo.getLatestExercisePlan(userId: userId)
    }

    func generateMealPlan() {
        guard let user = currentUser() else { error = "User not found"; return }
        isGeneratingMeal = true
        error = ""
        Task {
            do {
                let plan = try await planRepo.generateMealPlan(user: user, weekStart: weekStart)
                await MainActor.run { mealPlan = plan; isGeneratingMeal = false }
            } catch {
                await MainActor.run { self.error = error.localizedDescription; isGeneratingMeal = false }
            }
        }
    }

    func generateExercisePlan() {
        guard let user = currentUser() else { error = "User not found"; return }
        isGeneratingExercise = true
        error = ""
        Task {
            do {
                let plan = try await planRepo.generateExercisePlan(user: user, weekStart: weekStart)
                await MainActor.run { exercisePlan = plan; isGeneratingExercise = false }
            } catch {
                await MainActor.run { self.error = error.localizedDescription; isGeneratingExercise = false }
            }
        }
    }

    func swapMeal(day: String, meal: MealItem) {
        guard let user = currentUser() else { return }
        let key = "\(day)_\(meal.type)"
        swappingKey = key
        error = ""
        Task {
            do {
                let newMeal = try await planRepo.swapMeal(apiKey: user.claudeApiKey, day: day, meal: meal)
                await MainActor.run {
                    updateMeal(day: day, meal: meal, with: newMeal)
                    swappingKey = nil
                    if let userId = session.userId, let plan = mealPlan {
                        try? planRepo.saveMealPlan(userId: userId, weekStart: weekStart, plan: plan)
                    }
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription; swappingKey = nil }
            }
        }
    }

    func swapExercise(day: String, index: Int, exercise: ExerciseItem, workoutType: String) {
        guard let user = currentUser() else { return }
        let key = "\(day)_ex_\(index)"
        swappingKey = key
        error = ""
        Task {
            do {
                let newEx = try await planRepo.swapExercise(apiKey: user.claudeApiKey, exercise: exercise, workoutType: workoutType)
                await MainActor.run {
                    updateExercise(day: day, index: index, with: newEx)
                    swappingKey = nil
                    if let userId = session.userId, let plan = exercisePlan {
                        try? planRepo.saveExercisePlan(userId: userId, weekStart: weekStart, plan: plan)
                    }
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription; swappingKey = nil }
            }
        }
    }

    func clearError() { error = "" }

    private func currentUser() -> User? {
        guard let id = session.userId else { return nil }
        return try? userRepo.findUser(id: id)
    }

    private func updateMeal(day: String, meal: MealItem, with newMeal: MealItem) {
        guard let plan = mealPlan else { return }
        mealPlan = WeeklyMealPlan(days: plan.days.map { d in
            guard d.day == day else { return d }
            return DayMealPlan(day: d.day, meals: d.meals.map { m in m.type == meal.type ? newMeal : m })
        })
    }

    private func updateExercise(day: String, index: Int, with newEx: ExerciseItem) {
        guard let plan = exercisePlan else { return }
        exercisePlan = WeeklyExercisePlan(days: plan.days.map { d in
            guard d.day == day else { return d }
            var exList = d.exercises
            if index < exList.count { exList[index] = newEx }
            return DayExercisePlan(day: d.day, workoutType: d.workoutType, duration: d.duration,
                                   isRest: d.isRest, exercises: exList, warmup: d.warmup, cooldown: d.cooldown)
        })
    }
}
