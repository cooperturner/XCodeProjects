import SwiftData
import Foundation

enum ProfileSaveState { case idle, loading, saved, error(String) }

@Observable
class ProfileViewModel {
    var user: User?
    var saveState: ProfileSaveState = .idle

    private let repo: UserRepository
    private let session = SessionManager.shared

    init(modelContext: ModelContext) {
        self.repo = UserRepository(modelContext: modelContext)
        loadUser()
    }

    func loadUser() {
        guard let id = session.userId else { return }
        user = try? repo.findUser(id: id)
    }

    func saveProfile(name: String, age: String, weightKg: String, heightCm: String,
                     gender: String, goal: String, apiKey: String,
                     dietaryPreferences: String, dislikedFoods: String, sport: String) async {
        guard let ageInt = Int(age), let weight = Float(weightKg), let height = Int(heightCm) else {
            saveState = .error("Please check your inputs"); return
        }
        saveState = .loading
        guard let u = user else { saveState = .error("User not found"); return }

        u.name = name.trimmingCharacters(in: .whitespaces)
        u.age = ageInt
        u.weightKg = weight
        u.heightCm = height
        u.gender = gender
        u.goal = goal
        u.claudeApiKey = apiKey.trimmingCharacters(in: .whitespaces)
        u.dietaryPreferences = dietaryPreferences.trimmingCharacters(in: .whitespaces)
        u.dislikedFoods = dislikedFoods.trimmingCharacters(in: .whitespaces)
        u.sport = sport.trimmingCharacters(in: .whitespaces)
        u.dailyCalorieTarget = User.calculateCalorieTarget(weight: weight, height: height, age: ageInt, gender: gender, goal: goal)
        u.profileComplete = true

        do {
            try repo.save()
            session.profileComplete = true
            saveState = .saved
        } catch {
            saveState = .error(error.localizedDescription)
        }
    }

    func logout(onDone: () -> Void) {
        session.logout()
        user = nil
        onDone()
    }

    func resetState() { saveState = .idle }
}
