import SwiftData
import Foundation

@Observable
class ProgressViewModel {
    var entries: [WeightEntry] = []
    var error = ""

    private let repo: WeightRepository
    private let session = SessionManager.shared

    init(modelContext: ModelContext) {
        self.repo = WeightRepository(modelContext: modelContext)
        loadEntries()
    }

    func loadEntries() {
        guard let userId = session.userId else { return }
        entries = (try? repo.entries(userId: userId)) ?? []
    }

    func addEntry(date: String, weightKg: Float) {
        guard weightKg > 0 else { error = "Enter a valid weight"; return }
        guard let userId = session.userId else { return }
        try? repo.add(userId: userId, date: date, weightKg: weightKg)
        loadEntries()
    }

    func deleteEntry(_ entry: WeightEntry) {
        try? repo.delete(entry)
        loadEntries()
    }

    func clearError() { error = "" }
}
