import SwiftUI

struct HomeView: View {
    var profileVm: ProfileViewModel
    var trackerVm: TrackerViewModel

    private var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        if hour < 12 { return "Good morning" }
        if hour < 17 { return "Good afternoon" }
        return "Good evening"
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(greeting).font(.subheadline).foregroundStyle(Color.textSecondary)
                    Text(profileVm.user?.name.isEmpty == false ? profileVm.user!.name : "Athlete")
                        .font(.title).bold().foregroundStyle(Color.textPrimary)
                }

                // Calorie snapshot
                FitCard {
                    HStack {
                        Image(systemName: "flame.fill").foregroundStyle(Color.fitGreen)
                        Text("Today's Calories").font(.headline).foregroundStyle(Color.textPrimary)
                    }
                    CalorieProgressBar(
                        consumed: trackerVm.totalCalories,
                        target: profileVm.user?.dailyCalorieTarget ?? 2000
                    )
                    .padding(.top, 8)
                }

                // Macro snapshot
                if let user = profileVm.user {
                    FitCard {
                        Text("Daily Macros").font(.subheadline).foregroundStyle(Color.textSecondary)
                        let macros = MacroTargets.calculate(weightKg: user.weightKg, calories: user.dailyCalorieTarget, goal: user.goal)
                        VStack(spacing: 10) {
                            MacroRow(label: "Protein", consumed: Int(trackerVm.totalProtein), target: macros.proteinG, color: .fitBlue)
                            MacroRow(label: "Carbs",   consumed: Int(trackerVm.totalCarbs),   target: macros.carbsG, color: .fitOrange)
                            MacroRow(label: "Fat",     consumed: Int(trackerVm.totalFat),     target: macros.fatG,   color: .fitRed)
                        }
                        .padding(.top, 8)
                    }
                }

                // Quick stats
                if let user = profileVm.user {
                    HStack(spacing: 12) {
                        QuickStatCard(icon: "scalemass.fill", label: "Weight", value: String(format: "%.1f kg", user.weightKg))
                        QuickStatCard(icon: "target", label: "Goal", value: goalLabel(user.goal))
                        QuickStatCard(icon: "burn", label: "Target", value: "\(user.dailyCalorieTarget) kcal")
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
        }
        .background(Color.darkBg)
        .onAppear { trackerVm.loadToday() }
    }

    private func goalLabel(_ goal: String) -> String {
        switch goal {
        case "gain_muscle": return "Gain Muscle"
        case "lose_weight": return "Lose Weight"
        default: return "Maintain"
        }
    }
}

struct QuickStatCard: View {
    let icon: String
    let label: String
    let value: String

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon).foregroundStyle(Color.fitGreen).font(.title3)
            Text(value).font(.system(size: 13, weight: .semibold)).foregroundStyle(Color.textPrimary).lineLimit(1)
            Text(label).font(.system(size: 11)).foregroundStyle(Color.textSecondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color.darkCard)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
