import SwiftUI

struct MealPlanView: View {
    var vm: PlanViewModel

    private var today: String {
        Calendar.current.weekdaySymbols[Calendar.current.component(.weekday, from: Date()) - 1]
    }
    private var weekLabel: String {
        let cal = Calendar.current
        var comps = cal.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date())
        comps.weekday = 2
        let mon = cal.date(from: comps) ?? Date()
        let sun = cal.date(byAdding: .day, value: 6, to: mon) ?? Date()
        let f = DateFormatter(); f.dateFormat = "MMM d"
        return "\(f.string(from: mon)) – \(f.string(from: sun))"
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                HStack {
                    Image(systemName: "fork.knife").foregroundStyle(Color.fitGreen).font(.title2)
                    VStack(alignment: .leading) {
                        Text("Meal Plan").font(.title2).bold().foregroundStyle(Color.textPrimary)
                        Text("Week of \(weekLabel)").font(.system(size: 13)).foregroundStyle(Color.textSecondary)
                    }
                    Spacer()
                }

                FitButton(
                    title: vm.mealPlan == nil ? "Generate Meal Plan" : "Regenerate Meal Plan",
                    action: { vm.generateMealPlan() },
                    isLoading: vm.isGeneratingMeal
                )

                ErrorBanner(message: vm.error) { vm.clearError() }

                if vm.isGeneratingMeal {
                    FitCard {
                        VStack(spacing: 12) {
                            ProgressView().tint(Color.fitGreen)
                            Text("Generating your personalised meal plan…").foregroundStyle(Color.textSecondary).font(.system(size: 13))
                            Text("This may take up to 30 seconds").foregroundStyle(Color.textSecondary).font(.system(size: 11))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                    }
                }

                if let plan = vm.mealPlan, !vm.isGeneratingMeal {
                    ForEach(plan.days) { dayPlan in
                        DayMealCard(
                            dayPlan: dayPlan,
                            defaultExpanded: dayPlan.day.lowercased() == today.lowercased(),
                            swappingKey: vm.swappingKey,
                            onSwap: { meal in vm.swapMeal(day: dayPlan.day, meal: meal) }
                        )
                    }
                }

                if vm.mealPlan == nil && !vm.isGeneratingMeal {
                    VStack(spacing: 10) {
                        Image(systemName: "fork.knife").font(.system(size: 44)).foregroundStyle(Color.textSecondary)
                        Text("No meal plan yet").foregroundStyle(Color.textSecondary)
                        Text("Tap Generate to create your plan").font(.system(size: 13)).foregroundStyle(Color.textSecondary)
                    }
                    .frame(maxWidth: .infinity).padding(40)
                }
            }
            .padding(.horizontal, 16).padding(.vertical, 16)
        }
        .background(Color.darkBg)
    }
}

struct DayMealCard: View {
    let dayPlan: DayMealPlan
    let defaultExpanded: Bool
    let swappingKey: String?
    let onSwap: (MealItem) -> Void

    @State private var expanded: Bool

    init(dayPlan: DayMealPlan, defaultExpanded: Bool, swappingKey: String?, onSwap: @escaping (MealItem) -> Void) {
        self.dayPlan = dayPlan
        self.defaultExpanded = defaultExpanded
        self.swappingKey = swappingKey
        self.onSwap = onSwap
        _expanded = State(initialValue: defaultExpanded)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { expanded.toggle() }
            } label: {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(dayPlan.day).font(.headline).foregroundStyle(Color.textPrimary)
                        Text("\(dayPlan.totalCalories) kcal total").font(.system(size: 13)).foregroundStyle(Color.textSecondary)
                    }
                    Spacer()
                    Image(systemName: expanded ? "chevron.up" : "chevron.down").foregroundStyle(Color.textSecondary)
                }
                .padding(16)
            }

            if expanded {
                Divider().background(Color.darkSurface)
                VStack(spacing: 0) {
                    ForEach(Array(dayPlan.meals.enumerated()), id: \.element.id) { idx, meal in
                        if idx > 0 { Divider().background(Color.darkSurface).padding(.horizontal, 16) }
                        MealRowView(
                            meal: meal,
                            isSwapping: swappingKey == "\(dayPlan.day)_\(meal.type)",
                            onSwap: { onSwap(meal) }
                        )
                        .padding(16)
                    }
                }
            }
        }
        .background(Color.darkCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

struct MealRowView: View {
    let meal: MealItem
    let isSwapping: Bool
    let onSwap: () -> Void
    @State private var showDetails = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(meal.type.uppercased())
                        .font(.system(size: 10, weight: .bold)).tracking(1).foregroundStyle(Color.fitGreen)
                    Text(meal.name).font(.headline).foregroundStyle(Color.textPrimary)
                    HStack(spacing: 8) {
                        Text("\(meal.calories) kcal").font(.system(size: 13, weight: .semibold)).foregroundStyle(Color.textPrimary)
                        Text("P \(meal.protein)g").font(.system(size: 12)).foregroundStyle(Color.fitBlue)
                        Text("C \(meal.carbs)g").font(.system(size: 12)).foregroundStyle(Color.fitOrange)
                        Text("F \(meal.fat)g").font(.system(size: 12)).foregroundStyle(Color.fitRed)
                    }
                }
                Spacer()
                Button { if !isSwapping { onSwap() } } label: {
                    if isSwapping {
                        ProgressView().tint(Color.fitGreen).scaleEffect(0.8).frame(width: 24, height: 24)
                    } else {
                        Image(systemName: "arrow.left.arrow.right").foregroundStyle(Color.fitGreen)
                    }
                }
                .frame(width: 44, height: 44)
            }

            Button {
                withAnimation { showDetails.toggle() }
            } label: {
                HStack(spacing: 4) {
                    Text(showDetails ? "Hide details" : "Ingredients & prep")
                        .font(.system(size: 12)).foregroundStyle(Color.textSecondary)
                    Image(systemName: showDetails ? "chevron.up" : "chevron.down")
                        .font(.system(size: 11)).foregroundStyle(Color.textSecondary)
                }
            }

            if showDetails {
                VStack(alignment: .leading, spacing: 6) {
                    if !meal.ingredients.isEmpty {
                        Text("Ingredients").font(.system(size: 11, weight: .bold)).foregroundStyle(Color.textSecondary)
                        ForEach(meal.ingredients, id: \.self) { i in
                            Text("• \(i)").font(.system(size: 13)).foregroundStyle(Color.textPrimary)
                        }
                    }
                    if !meal.prep.isEmpty {
                        Text("Preparation").font(.system(size: 11, weight: .bold)).foregroundStyle(Color.textSecondary).padding(.top, 4)
                        Text(meal.prep).font(.system(size: 13)).foregroundStyle(Color.textPrimary)
                    }
                }
            }
        }
    }
}
