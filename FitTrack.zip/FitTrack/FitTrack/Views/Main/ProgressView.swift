import SwiftUI
import Charts

struct WeightProgressView: View {
    var vm: ProgressViewModel
    var onNavigateSettings: () -> Void
    @State private var showLogDialog = false

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                if !vm.entries.isEmpty {
                    StatsCard(entries: vm.entries)

                    FitCard {
                        Text("Weight Chart").font(.subheadline).foregroundStyle(Color.textSecondary)
                        WeightChart(entries: Array(vm.entries.suffix(30)))
                            .frame(height: 200)
                            .padding(.top, 8)
                    }
                }

                FitButton(title: "Log Weight") { showLogDialog = true }

                ErrorBanner(message: vm.error) { vm.clearError() }

                if vm.entries.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "chart.line.uptrend.xyaxis").font(.system(size: 44)).foregroundStyle(Color.textSecondary)
                        Text("No weight logged yet").foregroundStyle(Color.textSecondary)
                        Text("Tap Log Weight to start tracking").font(.system(size: 13)).foregroundStyle(Color.textSecondary)
                    }
                    .frame(maxWidth: .infinity).padding(40)
                }

                if !vm.entries.isEmpty {
                    Text("History").font(.headline).foregroundStyle(Color.textPrimary)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    ForEach(vm.entries.reversed(), id: \.id) { entry in
                        WeightHistoryRow(entry: entry, onDelete: { vm.deleteEntry(entry) })
                    }
                }
            }
            .padding(.horizontal, 16).padding(.vertical, 16)
        }
        .background(Color.darkBg)
        .navigationTitle("Progress")
        .navigationBarTitleDisplayMode(.large)
        .sheet(isPresented: $showLogDialog) {
            LogWeightSheet(onSave: { date, weight in
                vm.addEntry(date: date, weightKg: weight)
                showLogDialog = false
            }, onDismiss: { showLogDialog = false })
        }
    }
}

struct StatsCard: View {
    let entries: [WeightEntry]

    var body: some View {
        let first = entries.first!.weightKg
        let current = entries.last!.weightKg
        let change = current - first

        FitCard {
            HStack {
                StatItem(label: "Starting", value: String(format: "%.1f kg", first), color: .textSecondary)
                Spacer()
                Divider().frame(height: 48).background(Color.darkSurface)
                Spacer()
                StatItem(label: "Current", value: String(format: "%.1f kg", current), color: .fitGreen)
                Spacer()
                Divider().frame(height: 48).background(Color.darkSurface)
                Spacer()
                let changeColor: Color = change < 0 ? .fitGreen : change > 0 ? .fitRed : .textSecondary
                let prefix = change > 0 ? "+" : ""
                StatItem(label: "Change", value: "\(prefix)\(String(format: "%.1f", change)) kg", color: changeColor)
            }
        }
    }
}

struct StatItem: View {
    let label: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value).font(.system(size: 18, weight: .bold)).foregroundStyle(color)
            Text(label).font(.system(size: 12)).foregroundStyle(Color.textSecondary)
        }
    }
}

struct WeightChart: View {
    let entries: [WeightEntry]

    var body: some View {
        Chart {
            ForEach(entries, id: \.id) { entry in
                AreaMark(
                    x: .value("Date", entry.date),
                    y: .value("Weight", entry.weightKg)
                )
                .foregroundStyle(Color.fitGreen.opacity(0.2))
                .interpolationMethod(.catmullRom)

                LineMark(
                    x: .value("Date", entry.date),
                    y: .value("Weight", entry.weightKg)
                )
                .foregroundStyle(Color.fitGreen)
                .lineStyle(StrokeStyle(lineWidth: 2))
                .interpolationMethod(.catmullRom)

                PointMark(
                    x: .value("Date", entry.date),
                    y: .value("Weight", entry.weightKg)
                )
                .foregroundStyle(Color.fitGreen)
                .symbolSize(40)
            }
        }
        .chartXAxis {
            AxisMarks(values: .automatic(desiredCount: 3)) { value in
                AxisValueLabel {
                    if let str = value.as(String.self) {
                        Text(formatDateShort(str)).font(.system(size: 10)).foregroundStyle(Color.textSecondary)
                    }
                }
            }
        }
        .chartYAxis {
            AxisMarks { value in
                AxisGridLine(stroke: StrokeStyle(dash: [2])).foregroundStyle(Color.white.opacity(0.06))
                AxisValueLabel {
                    if let v = value.as(Double.self) {
                        Text("\(Int(v))kg").font(.system(size: 10)).foregroundStyle(Color.textSecondary)
                    }
                }
            }
        }
        .chartBackground { _ in Color.darkCard }
    }

    private func formatDateShort(_ dateStr: String) -> String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        guard let date = f.date(from: dateStr) else { return dateStr }
        let out = DateFormatter(); out.dateFormat = "d MMM"
        return out.string(from: date)
    }
}

struct WeightHistoryRow: View {
    let entry: WeightEntry
    let onDelete: () -> Void

    var body: some View {
        HStack {
            Image(systemName: "scalemass.fill").foregroundStyle(Color.fitGreen).font(.system(size: 18))
            VStack(alignment: .leading, spacing: 2) {
                Text(String(format: "%.1f kg", entry.weightKg)).font(.system(size: 16, weight: .semibold)).foregroundStyle(Color.textPrimary)
                Text(formatDateFull(entry.date)).font(.system(size: 12)).foregroundStyle(Color.textSecondary)
            }
            Spacer()
            Button { onDelete() } label: {
                Image(systemName: "trash").foregroundStyle(Color.textSecondary).font(.system(size: 16))
            }
        }
        .padding(14)
        .background(Color.darkCard)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private func formatDateFull(_ dateStr: String) -> String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        guard let date = f.date(from: dateStr) else { return dateStr }
        let out = DateFormatter(); out.dateFormat = "d MMM yyyy"
        return out.string(from: date)
    }
}

struct LogWeightSheet: View {
    var onSave: (String, Float) -> Void
    var onDismiss: () -> Void

    @State private var weight = ""
    @State private var date: String = {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"; return f.string(from: Date())
    }()

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                FitTextField(label: "Weight (kg)", text: $weight, keyboardType: .decimalPad)
                FitTextField(label: "Date (YYYY-MM-DD)", text: $date)
                Spacer()
            }
            .padding(20)
            .background(Color.darkBg)
            .navigationTitle("Log Weight")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") { onDismiss() }.foregroundStyle(Color.textSecondary)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Save") {
                        if let w = Float(weight) { onSave(date, w) }
                    }
                    .foregroundStyle(Color.fitGreen)
                    .disabled(weight.isEmpty)
                }
            }
        }
        .presentationDetents([.medium])
    }
}
